import React from 'react';
import { BlockContent } from '../types';

interface AboutProps {
  data: BlockContent;
}

const About: React.FC<AboutProps> = ({ data }) => {
  return (
    <section id="sobre" className="py-24 relative">
      <div className="container mx-auto px-6">
        <div className="glass-card rounded-3xl p-8 md:p-12 lg:p-16 flex flex-col md:flex-row items-center gap-12 lg:gap-20">
          
          <div className="w-full md:w-1/2 relative">
            <div className="relative z-10 rounded-2xl overflow-hidden border border-white/10 shadow-2xl">
              <img 
                src={data.imagem || "https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&q=80"}
                alt="Corretor" 
                className="w-full h-auto object-cover"
              />
            </div>
            {/* Decorativo */}
            <div className="absolute -top-6 -left-6 w-full h-full border border-brand-accent/30 rounded-2xl -z-0 hidden md:block" />
          </div>

          <div className="w-full md:w-1/2">
            <h2 className="font-serif text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-6">
              {data.titulo || "Experiência e Confiança"}
            </h2>
            <div className="w-20 h-1 bg-brand-accent mb-8" />
            <p className="text-slate-300 text-lg leading-relaxed mb-6 font-light">
              {data.texto}
            </p>
            <div className="flex gap-8 mt-8">
               <div>
                 <span className="block text-3xl font-serif text-brand-accent font-bold">10+</span>
                 <span className="text-sm text-slate-400 uppercase tracking-wide">Anos de Mercado</span>
               </div>
               <div>
                 <span className="block text-3xl font-serif text-brand-accent font-bold">500+</span>
                 <span className="text-sm text-slate-400 uppercase tracking-wide">Imóveis Vendidos</span>
               </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};

export default About;