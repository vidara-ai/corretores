import React, { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { Save, Loader2, Layout, Type, Palette } from 'lucide-react';
import { LandingConfig } from '../types';

export default function AdminLanding() {
  const [config, setConfig] = useState<LandingConfig>({
    esquema_cores: {
      primary: '#0f172a',
      secondary: '#1e293b',
      background: '#020617',
      accent: '#fbbf24'
    },
    fontes: {
      titulo: 'Playfair Display',
      texto: 'Inter'
    },
    glassmorphism: true
  });

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const loadConfig = async () => {
      // Carrega a configuração existente. maybeSingle evita erro se a tabela estiver vazia.
      const { data, error } = await supabase
        .from('landing_configuracoes')
        .select('*')
        .maybeSingle();

      if (data) {
          // Merge com os defaults para garantir que todos os campos existam
          setConfig(prev => ({ ...prev, ...data }));
      }
      setLoading(false);
    };

    loadConfig();
  }, []);

  const salvar = async () => {
    setSaving(true);
    // Upsert salva ou atualiza. O Supabase deve lidar com o ID/User context via RLS ou trigger se configurado,
    // ou assumimos que é uma configuração única por enquanto.
    const { error } = await supabase
      .from('landing_configuracoes')
      .upsert(config); 
      
    if (error) {
        console.error('Error saving config:', error);
        alert('Erro ao salvar as configurações.');
    } else {
        alert('Configurações salvas com sucesso!');
    }
    setSaving(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center text-white">
        <Loader2 className="animate-spin mr-2" /> Carregando editor...
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-50 font-sans p-6 md:p-12">
        <div className="max-w-4xl mx-auto">
            <header className="mb-10 border-b border-white/10 pb-6">
                <h1 className="text-3xl font-serif font-bold text-white mb-2">Personalizar Landing Page</h1>
                <p className="text-slate-400">Defina a aparência visual da sua página de vendas.</p>
            </header>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                
                <div className="lg:col-span-2 space-y-8">
                    
                    {/* CORES */}
                    <section className="glass-card p-6 rounded-2xl">
                        <div className="flex items-center gap-2 mb-6 text-brand-accent">
                            <Palette size={20} />
                            <h2 className="text-xl font-bold text-white">Esquema de Cores</h2>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            {Object.entries(config.esquema_cores).map(([key, value]) => (
                                <label key={key} className="flex flex-col gap-2">
                                    <span className="text-sm font-medium text-slate-300 capitalize">{key}</span>
                                    <div className="flex items-center gap-3 bg-white/5 p-2 rounded-lg border border-white/10">
                                        <input
                                            type="color"
                                            value={value as string}
                                            onChange={(e) =>
                                                setConfig({
                                                ...config,
                                                esquema_cores: {
                                                    ...config.esquema_cores,
                                                    [key]: e.target.value
                                                }
                                                })
                                            }
                                            className="w-10 h-10 rounded cursor-pointer bg-transparent border-none p-0"
                                        />
                                        <span className="text-xs font-mono text-slate-400">{value as string}</span>
                                    </div>
                                </label>
                            ))}
                        </div>
                    </section>

                    {/* FONTES */}
                    <section className="glass-card p-6 rounded-2xl">
                        <div className="flex items-center gap-2 mb-6 text-brand-accent">
                            <Type size={20} />
                            <h2 className="text-xl font-bold text-white">Tipografia</h2>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <label className="flex flex-col gap-2">
                                <span className="text-sm font-medium text-slate-300">Título Principal</span>
                                <select
                                    value={config.fontes.titulo}
                                    onChange={(e) =>
                                        setConfig({
                                        ...config,
                                        fontes: { ...config.fontes, titulo: e.target.value }
                                        })
                                    }
                                    className="bg-slate-900 border border-white/10 text-white rounded-lg p-3 focus:ring-2 focus:ring-brand-accent focus:outline-none"
                                >
                                    <option value="Playfair Display">Playfair Display</option>
                                    <option value="Montserrat">Montserrat</option>
                                    <option value="Lato">Lato</option>
                                    <option value="Merriweather">Merriweather</option>
                                </select>
                            </label>

                            <label className="flex flex-col gap-2">
                                <span className="text-sm font-medium text-slate-300">Texto Corrido</span>
                                <select
                                    value={config.fontes.texto}
                                    onChange={(e) =>
                                        setConfig({
                                        ...config,
                                        fontes: { ...config.fontes, texto: e.target.value }
                                        })
                                    }
                                    className="bg-slate-900 border border-white/10 text-white rounded-lg p-3 focus:ring-2 focus:ring-brand-accent focus:outline-none"
                                >
                                    <option value="Inter">Inter</option>
                                    <option value="Roboto">Roboto</option>
                                    <option value="Open Sans">Open Sans</option>
                                    <option value="Lato">Lato</option>
                                </select>
                            </label>
                        </div>
                    </section>

                    {/* GLASSMORPHISM */}
                    <section className="glass-card p-6 rounded-2xl">
                        <div className="flex items-center gap-2 mb-6 text-brand-accent">
                            <Layout size={20} />
                            <h2 className="text-xl font-bold text-white">Estilo Visual</h2>
                        </div>
                        
                        <label className="flex items-center gap-4 cursor-pointer group">
                            <div className="relative">
                                <input
                                    type="checkbox"
                                    checked={config.glassmorphism}
                                    onChange={(e) =>
                                        setConfig({ ...config, glassmorphism: e.target.checked })
                                    }
                                    className="sr-only peer"
                                />
                                <div className="w-14 h-8 bg-slate-700 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-brand-accent rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-7 after:w-7 after:transition-all peer-checked:bg-brand-accent"></div>
                            </div>
                            <span className="text-white font-medium group-hover:text-brand-accent transition-colors">
                                Ativar Efeito Glassmorphism (Vidro Fosco)
                            </span>
                        </label>
                    </section>

                    <div className="flex justify-end pt-4">
                        <button
                            onClick={salvar}
                            disabled={saving}
                            className="flex items-center gap-2 px-8 py-4 bg-brand-accent text-slate-950 font-bold rounded-xl hover:bg-brand-accentHover transition-all shadow-lg hover:shadow-brand-accent/20 disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                            {saving ? <Loader2 className="animate-spin" size={20} /> : <Save size={20} />}
                            Salvar Alterações
                        </button>
                    </div>

                </div>
                
                {/* Sidebar Info */}
                <div className="lg:col-span-1">
                   <div className="glass-card p-6 rounded-2xl sticky top-6">
                        <h3 className="text-lg font-bold text-white mb-4">Dicas de Design</h3>
                        <ul className="space-y-3 text-slate-400 text-sm">
                            <li className="flex gap-2">
                                <span className="text-brand-accent">•</span>
                                Use cores contrastantes para garantir a leitura.
                            </li>
                            <li className="flex gap-2">
                                <span className="text-brand-accent">•</span>
                                O efeito Glassmorphism funciona melhor com fundos escuros ou imagens.
                            </li>
                            <li className="flex gap-2">
                                <span className="text-brand-accent">•</span>
                                Fontes com serifa (como Playfair) trazem sofisticação para títulos.
                            </li>
                        </ul>
                   </div>
                </div>
            </div>
        </div>
    </div>
  );
}
