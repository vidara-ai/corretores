import React from 'react';
import { BlockContent } from '../types';

interface CTAProps {
  data: BlockContent;
}

const CTA: React.FC<CTAProps> = ({ data }) => {
  return (
    <section id="contato" className="py-32 relative flex items-center justify-center">
      {/* Background Glow */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="w-[600px] h-[600px] bg-brand-accent/10 rounded-full blur-[100px]" />
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-4xl mx-auto glass-card rounded-3xl p-12 md:p-20 text-center border border-white/20 shadow-2xl">
          <h2 className="font-serif text-4xl md:text-5xl font-bold text-white mb-6">
            {data.titulo || "Vamos encontrar o imóvel ideal?"}
          </h2>
          <p className="text-slate-300 text-lg md:text-xl mb-10 max-w-2xl mx-auto font-light">
            {data.subtitulo || "Atendimento exclusivo e personalizado para você realizar o melhor negócio."}
          </p>
          <a 
            href={data.botao_link || "#"} 
            className="inline-block bg-brand-accent text-slate-950 font-bold text-lg px-10 py-4 rounded-xl hover:bg-brand-accentHover hover:scale-105 transition-all shadow-lg shadow-brand-accent/25"
          >
            {data.botao_texto || "Agendar Consultoria"}
          </a>
        </div>
      </div>
    </section>
  );
};

export default CTA;