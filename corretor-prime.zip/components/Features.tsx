import React from 'react';
import { UserCheck, ShieldCheck, Star, Zap } from 'lucide-react';
import { BlockContent } from '../types';

interface FeaturesProps {
  data: BlockContent;
}

const Features: React.FC<FeaturesProps> = ({ data }) => {
  const getIcon = (index: number) => {
    const icons = [
      <UserCheck size={28} className="text-brand-accent" />,
      <ShieldCheck size={28} className="text-brand-accent" />,
      <Star size={28} className="text-brand-accent" />,
      <Zap size={28} className="text-brand-accent" />
    ];
    return icons[index % icons.length];
  };

  const items = data.itens || [];

  return (
    <section className="py-24 relative overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {items.map((item, index) => (
            <div 
              key={index} 
              className="glass-card p-8 rounded-2xl hover:bg-white/10 transition-all duration-300 group"
            >
              <div className="w-14 h-14 rounded-xl bg-slate-800 border border-white/10 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform shadow-lg">
                {getIcon(index)}
              </div>
              <h3 className="font-serif text-xl font-bold text-white mb-3 group-hover:text-brand-accent transition-colors">
                {item.titulo}
              </h3>
              <p className="text-slate-400 text-sm leading-relaxed">
                {item.descricao}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;