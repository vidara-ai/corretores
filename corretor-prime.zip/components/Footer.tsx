import React from 'react';
import { Instagram, Phone, Mail } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="border-t border-white/10 bg-slate-950/50 backdrop-blur-sm py-12">
      <div className="container mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="text-center md:text-left">
           <h3 className="font-serif text-xl font-bold text-white">Corretor<span className="text-brand-accent">.Prime</span></h3>
           <p className="text-slate-500 text-sm mt-1">© 2026 Todos os direitos reservados.</p>
        </div>
        
        <div className="flex gap-6">
          <a href="#" className="p-2 rounded-full bg-white/5 text-slate-400 hover:bg-brand-accent hover:text-slate-950 transition-all">
            <Phone size={20} />
          </a>
          <a href="#" className="p-2 rounded-full bg-white/5 text-slate-400 hover:bg-brand-accent hover:text-slate-950 transition-all">
            <Instagram size={20} />
          </a>
          <a href="#" className="p-2 rounded-full bg-white/5 text-slate-400 hover:bg-brand-accent hover:text-slate-950 transition-all">
            <Mail size={20} />
          </a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;