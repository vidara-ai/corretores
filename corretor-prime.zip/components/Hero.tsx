import React from 'react';
import { BlockContent } from '../types';
import { ArrowRight } from 'lucide-react';

interface HeroProps {
  data: BlockContent;
}

const Hero: React.FC<HeroProps> = ({ data }) => {
  const bgImage = data.imagem || "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?q=80&w=2070&auto=format&fit=crop";

  return (
    <section className="relative min-h-screen flex items-center pt-20 overflow-hidden">
      {/* Background Layer */}
      <div 
        className="absolute inset-0 bg-cover bg-center transition-transform duration-[20s] hover:scale-105"
        style={{ backgroundImage: `url('${bgImage}')` }}
      />
      {/* Overlay Gradiente */}
      <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-900/80 to-slate-900/40" />

      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-3xl glass-card p-10 md:p-16 rounded-3xl fade-in-up">
          <div className="inline-block px-4 py-1 rounded-full border border-brand-accent/30 bg-brand-accent/10 text-brand-accent text-sm font-semibold mb-6 tracking-wider uppercase">
            Imóveis Exclusivos
          </div>
          
          <h1 className="font-serif text-5xl md:text-6xl lg:text-7xl font-bold text-white leading-tight mb-8">
            {data.titulo || "Encontre o imóvel dos seus sonhos"}
          </h1>
          
          <p className="text-lg md:text-xl text-slate-300 mb-10 leading-relaxed max-w-xl font-light">
            {data.subtitulo || "Curadoria especializada em imóveis de alto padrão para quem busca viver o extraordinário."}
          </p>
          
          <div className="flex flex-col sm:flex-row gap-5">
            <a 
              href={data.botao_link || "#"} 
              className="px-8 py-4 bg-brand-accent text-slate-950 font-bold rounded-xl hover:bg-brand-accentHover transition-all flex items-center justify-center gap-2 shadow-lg shadow-brand-accent/20"
            >
              {data.botao_texto || "Falar no WhatsApp"}
            </a>
            <a 
              href="#imoveis" 
              className="px-8 py-4 bg-white/5 border border-white/20 text-white font-semibold rounded-xl hover:bg-white/10 transition-all flex items-center justify-center backdrop-blur-md"
            >
              Explorar Imóveis <ArrowRight size={18} className="ml-2" />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;