import React from 'react';
import { MapPin, BedDouble, Bath, Square } from 'lucide-react';
import { Property } from '../types';

interface PropertiesProps {
  properties: Property[];
}

const Properties: React.FC<PropertiesProps> = ({ properties }) => {
  const activeProperties = properties.filter(p => p.ativo !== false); 

  return (
    <section id="imoveis" className="py-32 relative">
      {/* Glow Effect Background */}
      <div className="absolute top-1/4 right-0 w-[500px] h-[500px] bg-brand-accent/5 rounded-full blur-[120px] pointer-events-none" />

      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 fade-in-up">
          <div className="max-w-2xl">
            <h2 className="font-serif text-4xl md:text-5xl font-bold text-white mb-6">
              Seleção <span className="text-brand-accent italic">Premium</span>
            </h2>
            <p className="text-slate-400 text-lg">
              Oportunidades únicas avaliadas rigorosamente para garantir o melhor investimento.
            </p>
          </div>
          <button className="hidden md:block text-brand-accent hover:text-white transition-colors border-b border-brand-accent pb-1 mt-6 md:mt-0">
            Ver todo o catálogo
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
          {activeProperties.map((property, index) => (
            <div 
              key={property.id} 
              className="group glass-card rounded-2xl overflow-hidden transition-all duration-500 hover:-translate-y-2"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="relative h-72 overflow-hidden">
                <img 
                  src={property.imagem_principal} 
                  alt={property.titulo}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent opacity-60" />
                
                {property.destaque && (
                  <div className="absolute top-4 left-4 bg-brand-accent text-slate-950 text-xs font-bold px-3 py-1.5 rounded uppercase tracking-wider shadow-lg">
                    Destaque
                  </div>
                )}
                
                <div className="absolute bottom-4 left-4 right-4 flex justify-between items-end">
                   <div className="text-white font-bold text-2xl drop-shadow-md">
                    {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL', maximumFractionDigits: 0 }).format(property.preco)}
                   </div>
                </div>
              </div>

              <div className="p-6">
                <h3 className="font-serif text-xl font-semibold text-white mb-2 line-clamp-1">
                  {property.titulo}
                </h3>
                <div className="flex items-center text-slate-400 text-sm mb-6">
                  <MapPin size={16} className="text-brand-accent mr-1.5" />
                  {property.localizacao}
                </div>

                {/* Features (Mockados visualmente para manter layout rico) */}
                <div className="flex justify-between border-t border-white/10 pt-4 text-slate-300 text-sm">
                  <div className="flex items-center gap-1"><BedDouble size={16}/> 3 Quartos</div>
                  <div className="flex items-center gap-1"><Bath size={16}/> 2 Banheiros</div>
                  <div className="flex items-center gap-1"><Square size={16}/> 120m²</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Properties;