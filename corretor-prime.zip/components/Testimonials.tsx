import React from 'react';
import { Quote } from 'lucide-react';
import { Testimonial } from '../types';

interface TestimonialsProps {
  testimonials: Testimonial[];
}

const Testimonials: React.FC<TestimonialsProps> = ({ testimonials }) => {
  return (
    <section id="depoimentos" className="py-32 bg-slate-900/50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="font-serif text-4xl font-bold text-white mb-4">
            Histórias de Sucesso
          </h2>
          <p className="text-slate-400">O que nossos clientes dizem sobre a experiência.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((item, index) => (
            <div 
              key={item.id} 
              className="glass-card p-8 rounded-2xl relative group hover:bg-white/10 transition-colors"
            >
              <Quote className="absolute top-6 right-6 text-white/5 group-hover:text-brand-accent/20 transition-colors" size={48} />
              
              <div className="mb-6">
                {[1,2,3,4,5].map(star => (
                  <span key={star} className="text-brand-accent text-sm">★</span>
                ))}
              </div>
              
              <p className="text-slate-300 italic mb-8 relative z-10 font-light leading-relaxed">
                "{item.texto}"
              </p>
              
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-brand-accent to-amber-600 flex items-center justify-center text-slate-900 font-bold font-serif">
                  {item.nome.charAt(0)}
                </div>
                <div>
                  <h4 className="text-white font-semibold text-sm">{item.nome}</h4>
                  <span className="text-xs text-slate-500 uppercase tracking-wider">Cliente</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;