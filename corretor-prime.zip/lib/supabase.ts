import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = 'https://nolastrwxqxxafwrfdyd.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im5vbGFzdHJ3eHF4eGFmd3JmZHlkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njk5MzA1NjcsImV4cCI6MjA4NTUwNjU2N30.-IvAzPrz3a4zfeXQ-JfwOWKRtejtQihUvmpV9wf8wIY';

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);